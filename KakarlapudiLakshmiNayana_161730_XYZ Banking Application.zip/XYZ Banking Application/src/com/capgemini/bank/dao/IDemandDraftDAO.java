package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;

public interface IDemandDraftDAO 
{
	public String addDemandDraftDetails(DemandDraft demanddraftbean) throws DemandDraftException;
	public DemandDraft getDemandDraftDetails(String transaction_id) throws DemandDraftException;
	
}

